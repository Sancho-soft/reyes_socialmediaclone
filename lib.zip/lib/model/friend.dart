class Friend {
  final String name;
  final String img;

  Friend({
    required this.name, 
    required this.img
    });
}